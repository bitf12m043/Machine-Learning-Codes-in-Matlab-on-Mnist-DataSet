function [ t ] = heaveside( x )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
  t=ones(length(x));
  negativeInd= x<0;
  t(negativeInd)=0;

end


function [ z ] = tanhFunction( a )

    ea=exp(a);
    eanegative=exp(-a);
    z=(ea-eanegative)./(ea+eanegative);
end

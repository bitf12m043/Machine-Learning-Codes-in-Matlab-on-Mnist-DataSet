function [ t ] = sinFunction( X)

  t=sin(X);

end


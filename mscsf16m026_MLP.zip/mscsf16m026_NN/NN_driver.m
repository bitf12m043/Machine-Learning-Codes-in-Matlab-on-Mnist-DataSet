%Data Generation
x=-1:0.040:1;

m=size(x,2);
x=[x; ones(1,m)]; %added bias  2x51

x=sort(x);
%Target Generation function
t=SqrFunction(x);  
%t=sinFunction(x);      
%t=AbsFunction(x);   
%t=heaveside(x); %for figure 5.4(d)
t=t';


%initialing weight of layer 1 and layer 2
w1=rand(3,2);
w2=rand(4,1);
m=size(x,2);
eta=0.001;
y=ones(m,1);
z1=zeros(50,1);
z2=zeros(50,1);
z3=zeros(50,1);

    for iter=1:12000
 
        gradient_Layer_1=zeros(4,1);
        gradient_Layer_2=zeros(3,2);       
        
        for i=1:m
            %for layer 1
            z=tanhFunction(w1*x(:,i));            
            z=[z;1];
            %for layer 2
            y(i)=sum(w2.*z);
            
            %calculating gradient of layer 1
            delta_k=y(i)-t(i);            
            Sj=delta_k*z;
            gradient_Layer_1=gradient_Layer_1+Sj;
            %calculating gradient of layer 2
            Sj_layer1=(1-(z.*z)).*(delta_k*w2);            
            gradient_ij=Sj_layer1(1:3)*x(:,i)';
            gradient_Layer_2=gradient_Layer_2+gradient_ij;
            %updating weights        
            w1=w1-eta*gradient_Layer_2;
            w2=w2-eta*gradient_Layer_1; 
        
        end
    
    end
 y=0;
 
%Calculating targets with learned w1 and w1 
for i=1:m
    Z=tanhFunction(w1*x(:,i));
    Z=[Z;1];
    z1(i)=Z(1);
    z2(i)=Z(2);
    z3(i)=Z(3);    
    y(i)=sum(sum(w2.*Z));
end


hold on;
plot(x(1,:),t(:,1),'.');
plot(x(1,:),y(1,:),'r');
plot(x(1,:),z1,'m');
plot(x(1,:),z2,'g');
plot(x(1,:),z3,'b');













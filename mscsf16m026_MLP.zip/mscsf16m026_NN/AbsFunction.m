function [ t ] = AbsFunction( X )
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here
t=abs(X);

end


function [ t ] = SqrFunction( X)

 t=X.^2; 

end


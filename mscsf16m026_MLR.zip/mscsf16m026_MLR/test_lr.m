function [output]=test_lr(w,X)
N=size(X,1);
X=[ones(N,1) X ];
output=zeros(N,size(w,2));
    
count = 0;    
    for i = 1:N
        a = X(i,:) * w;
        y = softmax_m(a);
        [~,y] = max(y);
        output(i,y)=1;
        
    end
    
    
   
end
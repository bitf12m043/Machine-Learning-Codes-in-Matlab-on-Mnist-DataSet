load mnist_uint8.mat
train_x=double(train_x);
train_y=double(train_y);
test_x=double(test_x);
test_y=double(test_y);

%train
w=train_lr(train_x,train_y);
%test
predict=test_lr(w,test_x);


plotconfusion(test_y',predict')
[c,cm,ind,pr]=confusion(test_y',predict');

[~,output]=max(predict,[],1);
[~,target]=max(test_y,[],1);
accuracy=mean(target==output)*100;

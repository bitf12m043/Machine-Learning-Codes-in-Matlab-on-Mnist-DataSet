function [p] = softmax_m(a)
    a = a -  max(a);
    p = exp(a)/sum(exp(a));
end
function [w]=train_lr(X,t)
[N D]=size(X);
[~, K]=size(t);
w=zeros(D+1,K); 
X=[ ones(N,1) X ];
n=0.18;
for k=1:10    
    for i=1:N
    yn=softmax_m(X(i,:)*w);
    Xn=(X(i,:))';
    Er=((yn-t(i,:)));
    w=w - n * (Xn *Er);
    n=n/1.001;
    end        

end
function w = train_lr(X, t)     
    X = changePicture(X);
    [N, D] = size(X);   
    wt = ones(D + 1, 1);
    X = [ones(N, 1) X];   
    for i = 1 : 20
        [wtp] = newton_raphson(wt, X, t);
        wt = wtp;       
        
    end
    w = wt;
end
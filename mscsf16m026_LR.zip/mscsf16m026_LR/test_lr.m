function [prediction] = test_lr(X, w)   
    N = size(X, 1);
    X = changePicture(X);
    X = [ones(N, 1) X];    
    a = (w') * (X');
    C1 = 1 ./ (1 + exp(-a));
    C0 = 1 - C1;    
    prediction = C1 > C0;
end
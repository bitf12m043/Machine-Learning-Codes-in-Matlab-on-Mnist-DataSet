load mnist_uint8.mat
train_x=double(train_x);
train_y=double(train_y);
test_x=double(test_x);
test_y=double(test_y);

class1=1;
class2=2;

%training data
class1_inds=find(train_y(:,class1)==1);
class2_inds=find(train_y(:,class2)==1);
n1=length(class1_inds);
n2=length(class2_inds);
n=n1+n2;
training_inds=[class1_inds ; class2_inds];
X=double(train_x(training_inds,:));
t=[zeros(n1,1) ; ones(n2,1)];

%testing data
class1_inds=find(test_y(:,class1)==1);
class2_inds=find(test_y(:,class2)==1);
n1=length(class1_inds);
n2=length(class2_inds);
testn=n1+n2;
testing_inds=[class1_inds ; class2_inds];
testX=double(test_x(testing_inds,:));
testt=[zeros(n1,1) ; ones(n2,1)];

%train
w=train_lr(X,t);

%test
test_Coding = test_y(testing_inds, 1:2);
[prediction] = test_lr(testX, w);
n_correct = length(find(testt == prediction'));
accuracy = mean(testt==prediction') *100 ;
prediction_COding = zeros(length(prediction), 2);

for i = 1 : length(prediction)
    if prediction(i) == 0
        prediction_COding(i,:) = [1 0];
    else
        prediction_COding(i,:) = [0 1];
    end
end

prediction_COding = logical(prediction_COding)';
test_Coding = logical(test_Coding)';
[c, cm, ind, per] = confusion(test_Coding, prediction_COding);
